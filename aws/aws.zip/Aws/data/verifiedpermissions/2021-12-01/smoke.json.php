<?php
// This file was auto-generated from sdk-root/src/data/verifiedpermissions/2021-12-01/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [],];
