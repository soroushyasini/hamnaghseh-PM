<?php
// This file was auto-generated from sdk-root/src/data/bedrock-agent-runtime/2023-07-26/paginators-1.json
return [ 'pagination' => [ 'GetAgentMemory' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxItems', 'result_key' => 'memoryContents', ], 'Retrieve' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'result_key' => 'retrievalResults', ], ],];
