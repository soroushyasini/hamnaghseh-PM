<?php
// This file was auto-generated from sdk-root/src/data/eks-auth/2023-11-26/waiters-2.json
return [ 'version' => 2, 'waiters' => [],];
