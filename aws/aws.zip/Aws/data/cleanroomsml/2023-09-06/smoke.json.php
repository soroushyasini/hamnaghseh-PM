<?php
// This file was auto-generated from sdk-root/src/data/cleanroomsml/2023-09-06/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [],];
