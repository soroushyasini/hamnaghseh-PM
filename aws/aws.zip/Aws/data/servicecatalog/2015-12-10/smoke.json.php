<?php
// This file was auto-generated from sdk-root/src/data/servicecatalog/2015-12-10/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListAcceptedPortfolioShares', 'input' => [], 'errorExpectedFromService' => false, ], ],];
